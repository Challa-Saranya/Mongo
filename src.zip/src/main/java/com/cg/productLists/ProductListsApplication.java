package com.cg.productLists;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg.productLists")
public class ProductListsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductListsApplication.class, args);
		System.out.println("this is product list project");
	}

}
