package com.cg.productLists.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.productLists.dto.Product;
import com.cg.productLists.service.ProductService;

@RestController
@RequestMapping("/product")
@CrossOrigin(origins="http://localhost:4200")
public class ProductController {
	@Autowired
	ProductService productService;
	@PostMapping("/addAllData")
	public ResponseEntity<Product> add(@RequestBody Product p) 
	{
		Product data=productService.add(p);
		
		if(data==null) {
			return new ResponseEntity("data not added",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Product>(p,HttpStatus.OK);
				}

	@GetMapping("/getAllData")
	public ResponseEntity<List<Product>> getAll(){
			
			List<Product> myList=productService.showAll();
			if(myList.isEmpty()) {
				return new ResponseEntity("no emp found",HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<List<Product>>(myList,HttpStatus.OK);
	}
	
	@DeleteMapping("/deletById")
	public String deleteById(@RequestParam("id") Integer pId) {
	productService.deleteProduct(pId);
		return pId+"is deleted";
	}
	
	@GetMapping("/searchById")
	public Product searchById(@RequestParam("id") Integer pId) {
	return productService.searchById(pId);
	
	}
	
	@GetMapping("/searchByName")
	public List<Product> searchByName(@RequestParam("name") String pName) {
		return productService.searchByName(pName);
	}
}
