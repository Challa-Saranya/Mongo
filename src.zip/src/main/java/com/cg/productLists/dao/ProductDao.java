package com.cg.productLists.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.productLists.dto.Product;

public interface ProductDao extends JpaRepository<Product,Integer>{
	
}
