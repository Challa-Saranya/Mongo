package com.cg.productLists.dto;

import javax.persistence.Entity;

import javax.persistence.Id;
@Entity
public class Product {
	@Id
	private Integer id;
	private String name;
	private String itemName;
	private Double price;
	private String description;
	private String isActive;
	public Product() {
		
	}
	public Product(Integer id, String name, String itemName, Double price, String description, String isActive) {
		super();
		this.id = id;
		this.name = name;
		this.itemName = itemName;
		this.price = price;
		this.description = description;
		this.isActive = isActive;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	
	

}
