package com.cg.productLists.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.productLists.dao.ProductDao;
import com.cg.productLists.dto.Product;

@Service
public class ProductServiceImpl implements ProductService{
	 @Autowired
		ProductDao productDao;
	@Override
	public List<Product> showAll() {
		return productDao.findAll();
	}

	@Override
	public Product add(Product p) {
		
		return productDao.save(p);
	}

	@Override
	public List<Product> searchByName(String name) {
		List<Product> products=productDao.findAll();
		List<Product> productsByName=new ArrayList<Product>();
		for(Product product:products) {
			if(product.getName().equals(name))
				productsByName.add(product);
			else if(product.getItemName().equals(name))
				productsByName.add(product);
		}
		return productsByName;
	}

	@Override
	public Product searchById(int pid) {
Optional<Product> pro1=productDao.findById(pid);
		
       Product pro=pro1.get();	
          return pro;   
	}

	@Override
	public void deleteProduct(int pId) {
		// TODO Auto-generated method stub
		productDao.deleteById(pId);
	}

}
