package com.cg.productLists.service;

import java.util.List;

import com.cg.productLists.dto.Product;

public interface ProductService {
	public List<Product> showAll();
	public Product add(Product p);
	public List<Product> searchByName(String name);
	public Product searchById(int pid);
	public void deleteProduct(int pId);
}
