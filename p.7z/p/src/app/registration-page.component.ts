import { Component, OnInit } from '@angular/core';
import { User } from './user';
import { UserService } from './user.service';

@Component({
  selector: 'app-registration-page',
  templateUrl: './registration-page.component.html',
  styleUrls: ['./registration-page.component.css']
})
export class RegistrationPageComponent implements OnInit {

  constructor(private userService:UserService) { }

  ngOnInit() {
  }
  onSave(employeeForm:User){
    console.log(employeeForm); 
    this.userService.addUser(employeeForm);
   
  }

}
