export interface User {
    firstName:String,
    phonenumber:String,
    email:String,
    password:string,
    confirmpassword:String
}
