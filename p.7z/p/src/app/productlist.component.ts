import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/service';
import { ProductserviceService } from 'src/app/productservice.service';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {
  products: any[]=[];
  /* searchtermId:number;
  searchtemId1:number; */
  searchName=true;
  searchId=false;
  searchterm:any;
  filteredProducts:Product[];
  private _searchterm:string;
  searchterm1:any;
  /* get searchterm():any{
    return this._searchterm;

  }
  set searchterm(value:any){
    this._searchterm=value;
    this.filteredProducts=this.filteredProduct1(value);
  }
  filteredProduct1(searchString:any){
    return this.products.filter(product=>product.name.toLowerCase().startsWith(searchString.toLowerCase()));
  } */

  

  constructor(private productservice: ProductserviceService) { }

  ngOnInit() {
  this.productservice.getProducts().subscribe((data:any)=>this.products=data);
   this.filteredProducts=this.products;
  }
  addToCart(){
    alert("Item Added to Cart")
  }
  addToWishList(){
    alert("Item added to wishlist")
  }
  search(searchterm){
    
      if(!isNaN(searchterm)){
          console.log("in number");
          this.searchId=true;
          this.searchName=false;
      this.productservice.searchById(searchterm).subscribe((data:any)=>this.products=data);
        }
      else{
console.log("in string");
this.searchName=true;
      this.productservice.searchByName(searchterm).subscribe((data:any)=>this.products=data);
      }
     
      this.searchterm1=this.searchterm;
       
      }
      /* searchId(searchtermId){
        this.searchtemId1=searchtermId;
        this.productservice.searchById(searchtermId).subscribe((data:any)=>this.products=data);
      } */

      delete(product){
        let d=this.products.lastIndexOf(product);
         this.products.splice(d,1);
        this.productservice.deleteById(product).subscribe();
      }

}
