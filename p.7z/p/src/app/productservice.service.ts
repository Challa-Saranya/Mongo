import { Injectable } from '@angular/core';
import { Product } from 'src/app/service';
import {HttpClient} from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {
  private listproducts: Product[] = [
    /* {
    id : 1,
    name:"Laptop",
    ItemName:"Dell Laptop",
    price:36000,
    description:"Inter Core 8,Camera",
    photopath:'assets/images/laptop.jpg',
    isActive:true

  },{
    id : 2,
    name:"Laptops",
    ItemName:"Dell Laptop",
    price:38000,
    description:"Inter Core 8,Camera",
    photopath:'assets/images/image.jpg',
    isActive:true



  },{
    id : 3,
    name:"Laptop",
    ItemName:"Apple Laptop",
    price:50000,
    description:"Inter Core 8,Camera",
    photopath:'assets/images/apple.jpg',
    isActive:true

  },{
    id : 4,
    name:"Laptop",
    ItemName:"Hp Laptop",
    price:40000,
    description:"Inter Core 8,Camera",
    photopath:'assets/images/HP.png',
    isActive:true
  },
  {
    id : 5,
    name:"Mobiles",
    ItemName:"Redmi",
    price:18000,
    description:"Inter Core 8,Camera",
    photopath:'assets/images/mi.jpg',
    isActive:true
  },
  {
    id : 6,
    name:"Mobile",
    ItemName:"OnePlus",
    price:16000,
    description:"Inter Core 8,Camera",
    photopath:'assets/images/oneplus.jpg',
    isActive:true
  },
  {
    id : 7,
    name:"Mobile",
    ItemName:"Micromax",
    price:21000,
    description:"Inter Core 8,Camera",
    photopath:'assets/images/miicromax.jpg',
    isActive:true
  },
  {
    id : 8,
    name:"Mobile",
    ItemName:"vivo",
    price:26000,
    description:"Inter Core 8,Camera",
    photopath:'assets/images/vivo.jpg',
    isActive:true
  } */
];
  getProducts(){
    return this.http.get("http://localhost:9997/product/getAllData");

  }
   deleteById(product){
    return this.http.delete("http://localhost:9997/product/deletById?id="+product.id);
} 
searchById(pid:number){
return this.http.get("http://localhost:9997/product/searchById?id="+pid);
}
searchByName(name:string){
return this.http.get("http://localhost:9997/product/searchByName?name="+name);
}

  constructor(private http:HttpClient) { }
}
