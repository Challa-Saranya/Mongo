import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductlistComponent } from './productlist.component';
import { ProductpipePipe } from './productpipe.pipe';
import { LoginPageComponent } from './login-page.component';
import { RegistrationPageComponent } from './registration-page.component';
import { ContactpageComponent } from './contactpage.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductlistComponent,
    ProductpipePipe,
    LoginPageComponent,
    RegistrationPageComponent,
    ContactpageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
