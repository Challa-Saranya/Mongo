import { Injectable } from '@angular/core';
import { Router } from '../../node_modules/@angular/router';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  userDetails:User[]=[

  ];

  constructor(private router:Router){}
  addUser(user){
    console.log(user);
    this.userDetails.push(user);
    console.log(this.userDetails);
    //this.router.navigate(["/login"])
  }
}
