import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginPageComponent } from './login-page.component';
import { RegistrationPageComponent } from './registration-page.component';
import { ProductlistComponent } from './productlist.component';


const routes: Routes = [
  {path:'login',component:LoginPageComponent},
  {path:'signup',component:RegistrationPageComponent},
  {path:'products',component:ProductlistComponent},
  
  {path:'',redirectTo:'/login',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
