package com.reservation.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.web.bind.annotation.CrossOrigin;

@Document
public class Tickets {
	@Id
	private Integer ticketId;
	
	
	
	private String seatNo;
	private Integer price;
	private String status;
	public Integer getTicketId() {
		return ticketId;
	}
	public void setTicketId(Integer ticketId) {
		this.ticketId = ticketId;
	}
	public String getSeatNo() {
		return seatNo;
	}
	public void setSeatNo(String seatNo) {
		this.seatNo = seatNo;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Tickets [ticketId=" + ticketId + ", seatNo=" + seatNo + ", price=" + price + ", status=" + status + "]";
	}
	public Tickets(Integer ticketId, String seatNo, Integer price, String status) {
		super();
		this.ticketId = ticketId;
		this.seatNo = seatNo;
		this.price = price;
		this.status = status;
	}
	public Tickets() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

	
	
	
	
	
	
	
	

}
