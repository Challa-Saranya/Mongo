package com.reservation.dto;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Booking {
    @Id
	private Integer BookingId;
	private Integer totalPrice;
	private List<Tickets> tickets;
	
	public Integer getBookingId() {
		return BookingId;
	}
	public void setBookingId(Integer bookingId) {
		BookingId = bookingId;
	}
	public Integer getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Integer totalPrice) {
		this.totalPrice = totalPrice;
	}
	public List<Tickets> getTickets() {
		return tickets;
	}
	public void setTickets(List<Tickets> tickets) {
		this.tickets = tickets;
	}
	@Override
	public String toString() {
		return "Booking [BookingId=" + BookingId + ", totalPrice=" + totalPrice + ", tickets=" + tickets + "]";
	}
	public Booking(Integer bookingId, Integer totalPrice, List<Tickets> tickets) {
		super();
		BookingId = bookingId;
		this.totalPrice = totalPrice;
		this.tickets = tickets;
	}
	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
