package com.reservation.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Bus {
	
	private String busName;
	@Id
	private String busCode;
	private String source;
	private String destination;
	private String noOfSeats;
	public String getBusName() {
		return busName;
	}
	public void setBusName(String busName) {
		this.busName = busName;
	}
	public String getBusCode() {
		return busCode;
	}
	public void setBusCode(String busCode) {
		this.busCode = busCode;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(String noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	public Bus(String busName, String busCode, String source, String destination, String noOfSeats) {
		super();
		this.busName = busName;
		this.busCode = busCode;
		this.source = source;
		this.destination = destination;
		this.noOfSeats = noOfSeats;
	}
	public Bus() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
