package com.reservation.dao;

import java.util.List;

import com.reservation.dto.Booking;
import com.reservation.dto.Tickets;
import com.reservation.dto.User;

public interface UserDao {
	
	public User addUser(User user);
	
	boolean validateUser(String emailId, String password);
	
	public Integer bookTicketDetails(List<Tickets> tickets);
	
	public Booking getBookingByIdDetails(Integer bookingId);

}
