package com.reservation.dao;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.reservation.dto.Booking;
import com.reservation.dto.Bus;
import com.reservation.dto.Tickets;

@Repository
public class AdminDaoImpl implements AdminDao{

	@Autowired
	MongoTemplate mongo;
	
	Booking booking=new Booking();
	Integer val=0;
	

	
	@Override
	public Bus addBusDetails(Bus bus) {
		// TODO Auto-generated method stub
		return mongo.save(bus);
	}

	@Override
	public List<Bus> getBusDetails() {
		// TODO Auto-generated method stub
		List<Bus> data= mongo.findAll(Bus.class);
		
		return data;
	}

	@Override
	public Bus getBusDetailsById(String buscode) {
		// TODO Auto-generated method stub
		System.out.println("s");
		System.out.println(mongo.findById(buscode, Bus.class));
		
	return	mongo.findById(buscode, Bus.class);
		
		
	}

	@Override
	public String deleteBusDetails(String buscode) {
		// TODO Auto-generated method stub
		Bus data= mongo.findById(buscode, Bus.class);
		mongo.remove(data);
		
		return data.getBusCode();
	}

	@Override
	public Bus updateBusDetails(Bus busdeatils) {
		// TODO Auto-generated method stub
		Bus data=mongo.findById(busdeatils.getBusCode(), Bus.class);
		data.setBusName(busdeatils.getBusName());
		data.setDestination(busdeatils.getDestination());
		data.setNoOfSeats(busdeatils.getNoOfSeats());
		data.setSource(busdeatils.getSource());
		mongo.save(data);
		
		return data;
	}

	

	@Override
	public List<Booking> getTicketDetails() {
		// TODO Auto-generated method stub
		return mongo.findAll(Booking.class);
	}

}
