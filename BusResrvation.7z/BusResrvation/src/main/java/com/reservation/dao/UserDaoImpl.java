package com.reservation.dao;


import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.reservation.dto.Booking;
import com.reservation.dto.Tickets;
import com.reservation.dto.User;


@Repository
public class UserDaoImpl implements UserDao{

	@Autowired
	MongoTemplate mongo;
	
	Booking booking=new Booking();
	Integer val=0;
	
	
	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return mongo.save(user);
	}

	@Override
	public boolean validateUser(String emailId, String password) {
		// TODO Auto-generated method stub
		List<User> users=mongo.findAll(User.class);
		for(User r:users) {
			if(r.getEmailId().equals(emailId)&&(r.getPassword().equals(password)))
			
			 {
				return true;
			}
		}
		return false;
	}

	@Override
	public Integer bookTicketDetails(List<Tickets> tickets) {
		// TODO Auto-generated method stub
		Random random=new Random();
		System.out.println(tickets);
		
		for (Tickets tickets2 : tickets) {
			
			for (Tickets ticketsobj : tickets) {
			ticketsobj.setTicketId(random.nextInt());
			val=val+ticketsobj.getPrice();
			mongo.save(ticketsobj);
		}
		booking.setBookingId(random.nextInt());
		booking.setTotalPrice(val);
		booking.setTickets(tickets);
		
		mongo.save(booking);
		System.out.println("lllll"+booking);
		
			
		}
		return booking.getBookingId();
		
		
	}

	@Override
	public Booking getBookingByIdDetails(Integer bookingId) {
		// TODO Auto-generated method stub
		System.out.println(bookingId);
		
		Booking dummyBooking=new Booking();
		
		List<Booking> booking= mongo.findAll(Booking.class);
		
		
		for (Booking booking2 : booking) {
			
			
			if(booking2.getBookingId().equals(bookingId))
			{
				return booking2;
			}
			
		}
		
	
		return dummyBooking;
	}
	

}
