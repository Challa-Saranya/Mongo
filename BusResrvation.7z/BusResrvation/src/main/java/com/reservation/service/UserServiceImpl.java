package com.reservation.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reservation.dao.UserDao;
import com.reservation.dto.Booking;
import com.reservation.dto.Tickets;
import com.reservation.dto.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userdao;
	
	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return userdao.addUser(user);
	}

	@Override
	public boolean validateUser(String emailId, String password) {
		// TODO Auto-generated method stub
		return userdao.validateUser(emailId, password);
	}

	@Override
	public Integer bookTicketDetails(List<Tickets> tickets) {
		// TODO Auto-generated method stub
		return userdao.bookTicketDetails(tickets);
	}

	@Override
	public Booking getBookingByIdDetails(Integer bookingId) {
		// TODO Auto-generated method stub
		return userdao.getBookingByIdDetails(bookingId);
	}

}
