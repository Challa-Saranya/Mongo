package com.reservation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reservation.dao.AdminDao;

import com.reservation.dto.Booking;
import com.reservation.dto.Bus;
import com.reservation.dto.Tickets;
@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	AdminDao admindao;
	
	@Override
	public Bus addBusDetails(Bus bus) {
		// TODO Auto-generated method stub
		return admindao.addBusDetails(bus);
	}

	@Override
	public List<Bus> getBusDetails() {
		// TODO Auto-generated method stub
		return admindao.getBusDetails();
	}

	@Override
	public Bus getBusDetailsById(String buscode) {
		// TODO Auto-generated method stub
		System.out.println("s");
		return admindao.getBusDetailsById(buscode);
	}

	@Override
	public String deleteBusDetails(String buscode) {
		// TODO Auto-generated method stub
		return admindao.deleteBusDetails(buscode);
	}

	@Override
	public Bus updateBusDetails(Bus busdeatils) {
		// TODO Auto-generated method stub
		return admindao.updateBusDetails(busdeatils);
	}

	

	@Override
	public List<Booking> getTicketDetails() {
		// TODO Auto-generated method stub
		return admindao.getTicketDetails();
	}

}
