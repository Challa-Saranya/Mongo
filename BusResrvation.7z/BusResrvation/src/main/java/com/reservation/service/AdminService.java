package com.reservation.service;

import java.util.List;

import com.reservation.dto.Booking;
import com.reservation.dto.Bus;
import com.reservation.dto.Tickets;

public interface AdminService {
	
	public Bus addBusDetails(Bus bus);
	
	public List<Bus> getBusDetails();
	
	public Bus getBusDetailsById(String buscode);
	
	public String deleteBusDetails(String buscode);
	
	public Bus updateBusDetails(Bus busdeatils);
	
	
	
	public List<Booking> getTicketDetails();

}
