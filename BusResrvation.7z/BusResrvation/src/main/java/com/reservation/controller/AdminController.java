package com.reservation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.reservation.dto.Booking;
import com.reservation.dto.Bus;
import com.reservation.dto.Tickets;
import com.reservation.service.AdminService;


@RestController
@RequestMapping("/admin")
@CrossOrigin(origins="http://localhost:4200")
public class AdminController {
	
	@Autowired
	AdminService adiminservice;
	
	@PostMapping("/addbus")
	public Bus addingBus(@RequestBody Bus bus)
	{
		return adiminservice.addBusDetails(bus);
	}
	
	@GetMapping("/viewbus")
	public List<Bus> getbus()
	{
		return adiminservice.getBusDetails();
	}
	
	@GetMapping("/viewbyid")
	public Bus getbusbyid(@RequestParam String busCode)
	{
		
		System.out.println("s");
	    return adiminservice.getBusDetailsById(busCode);	
	    
	}
	
	@DeleteMapping("deletebyid")
	public String deletebus(@RequestParam String busCode)
	{
		String val= adiminservice.deleteBusDetails(busCode);
		if(val!=null)
		{
			return "Bus with id "+val+"deleted succesfully";
		}
		else {
			return "no bus found";
		}
	}
	
	@PutMapping("/updatebus")
	public Bus updateBus(@RequestBody Bus busdeatils)
	{
		return adiminservice.updateBusDetails(busdeatils);
	}
	
	
	
	@GetMapping("/getTickets")
	public List<Booking> getTickets()
	{
		return adiminservice.getTicketDetails();
	}

}
