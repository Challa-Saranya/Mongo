package com.reservation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.reservation.dto.Booking;
import com.reservation.dto.Tickets;
import com.reservation.dto.User;
import com.reservation.service.UserService;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins="http://localhost:4200")
public class UserController {
	
	@Autowired
	UserService userservice;
	
	@PostMapping("/adduser")
	public User useradding(@RequestBody User user)
	{
		return userservice.addUser(user);
		
	}
	
	@GetMapping("/validatinguser")
	public Boolean validateUser(@RequestParam("emailId") String emailId,@RequestParam("password") String password)
	{
		return userservice.validateUser(emailId, password);
		
	}
	
	
	@PostMapping("/createticket")
	public Integer bookTicket(@RequestBody List<Tickets> tickets)
	{
		
		
		Integer val= userservice.bookTicketDetails(tickets);
		if(val!=null)
		{
			System.out.println("ticket booked with seat no"+val);
			return val;
		}
		else {
			return 0;
		}
	}
	
	@GetMapping("/getTicketById")
	public Booking getBookinById(@RequestParam Integer bookingId)
	{
	  return userservice.getBookingByIdDetails(bookingId);
	}
	
	

}
