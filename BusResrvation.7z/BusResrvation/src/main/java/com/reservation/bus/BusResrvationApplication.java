package com.reservation.bus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.reservation")
public class BusResrvationApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusResrvationApplication.class, args);
		System.out.println("runningg");
	}

}
