package com.cg.signup.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.signup.dto.Signup;


@Repository
public interface Signuprepository extends JpaRepository<Signup, Integer> {

}
