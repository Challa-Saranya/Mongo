package com.cg.signup.service;

import java.util.List;

import com.cg.signup.dto.Signup;

public interface Signupservice {
	public boolean validateUser(String email, String password);
	public List<Signup> getUser();
	public boolean validUser(Signup user);
	public Signup addUser(Signup user);
	

}
