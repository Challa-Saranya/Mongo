package com.cg.signup.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.signup.dto.Signup;
import com.cg.signup.service.Signupservice;

@RestController
@RequestMapping("/signuplist")
//@CrossOrigin(origins="http://localhost:4200")
public class SignupController {
	@Autowired
	Signupservice signupservice;
	@GetMapping("/getall")
	public List<Signup> getUser(){
		return signupservice.getUser();
		
	}
	@RequestMapping(value="/validateUser/{email}/{password}",method=RequestMethod.GET)
	public boolean validateUser(@PathVariable("email") String email,@PathVariable("password") String password) {
		return signupservice.validateUser(email, password);
	}
	@PostMapping("/addall")
	public boolean addUser(@RequestBody Signup user) {
		boolean result=signupservice.validUser(user);
		System.out.println("in controller"+result);
		if(!result) {
			Signup userdata=signupservice.addUser(user);
		}
		return result;
	}
	
	

}
