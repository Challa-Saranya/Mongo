package com.cg.signup.dto;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="signuptable")
public class Signup {
	@Id
	@GeneratedValue
	private Integer id;
	@Column(name="firstname")
	private String firstname;
	@Column(name="lastname")
	private String lastname;
	@Column(name="gender")
	private String gender;
	@Column(name="birthdate")
	private String birthdate;
	@Column(name="phnum")
	private String phnum;
	@Column(name="email")
	private String email;
	@Column(name="password")
	private String password;
	@Column(name="CnfPwd")
	private String CnfPwd;
	public Signup() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Signup(Integer id, String firstname, String lastname, String gender, String birthdate, String phnum,
			String email, String password, String cnfPwd) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.birthdate = birthdate;
		this.phnum = phnum;
		this.email = email;
		this.password = password;
		CnfPwd = cnfPwd;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}
	public String getPhnum() {
		return phnum;
	}
	public void setPhnum(String phnum) {
		this.phnum = phnum;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCnfPwd() {
		return CnfPwd;
	}
	public void setCnfPwd(String cnfPwd) {
		CnfPwd = cnfPwd;
	}
	@Override
	public String toString() {
		return "Signup [id=" + id + ", firstname=" + firstname + ", lastname=" + lastname + ", gender=" + gender
				+ ", birthdate=" + birthdate + ", phnum=" + phnum + ", email=" + email + ", password=" + password
				+ ", CnfPwd=" + CnfPwd + "]";
	}
	
}
