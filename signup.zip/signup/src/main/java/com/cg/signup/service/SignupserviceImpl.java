package com.cg.signup.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.signup.dao.Signuprepository;
import com.cg.signup.dto.Signup;
@Service
public class SignupserviceImpl implements Signupservice {
	@Autowired
	Signuprepository Signuprepository;

	@Override
	public boolean validateUser(String email, String password) {
		// TODO Auto-generated method stub
		List<Signup> signup=Signuprepository.findAll();
		for(Signup s:signup) {
			if(s.getEmail().equals(email)&&(s.getPassword().equals(password))) {
				return true;
			}
		}
		return false;
	}

	@Override
	public List<Signup> getUser() {
		// TODO Auto-generated method stub
		return Signuprepository.findAll();
	}

	@Override
	public boolean validUser(Signup user) {
		// TODO Auto-generated method stub
		List<Signup> usersdata=Signuprepository.findAll();
		for(Signup p:usersdata) {
			if(user.getFirstname().equalsIgnoreCase(p.getFirstname())) {
				return true;
			}
		}
		System.out.println("In Service User doesnot exist"+false);
		return false;
	}

	@Override
	public Signup addUser(Signup user) {
		// TODO Auto-generated method stub
		return Signuprepository.save(user);
	}

}
